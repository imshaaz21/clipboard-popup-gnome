import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk?version=4.0';

import {ExtensionPreferences, gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class ClipboardPopupPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        const page = new Adw.PreferencesPage();
        window.add(page);

        const group = new Adw.PreferencesGroup({title: _('Clipboard history')});
        page.add(group);

        const sizeRow = new Adw.SpinRow({
            title: _('History size'),
            subtitle: _('Maximum unpinned entries kept'),
            adjustment: new Gtk.Adjustment({lower: 5, upper: 200, step_increment: 5}),
        });
        settings.bind('history-size', sizeRow, 'value', Gio.SettingsBindFlags.DEFAULT);
        group.add(sizeRow);

        const previewRow = new Adw.SpinRow({
            title: _('Text preview length'),
            subtitle: _('Characters shown per text entry'),
            adjustment: new Gtk.Adjustment({lower: 20, upper: 300, step_increment: 10}),
        });
        settings.bind('preview-length', previewRow, 'value', Gio.SettingsBindFlags.DEFAULT);
        group.add(previewRow);

        const pasteRow = new Adw.SwitchRow({
            title: _('Paste on select'),
            subtitle: _('Simulate a paste keypress after picking an entry'),
        });
        settings.bind('paste-on-select', pasteRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(pasteRow);

        const privateRow = new Adw.SwitchRow({
            title: _('Private mode'),
            subtitle: _('Stop recording clipboard contents until turned off'),
        });
        settings.bind('private-mode', privateRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(privateRow);

        const notifyRow = new Adw.SwitchRow({
            title: _('Notify on copy'),
            subtitle: _('Show an OSD when new content is recorded'),
        });
        settings.bind('notify-on-copy', notifyRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(notifyRow);

        const confirmRow = new Adw.SwitchRow({
            title: _('Confirm clear'),
            subtitle: _('Require a second click before wiping history'),
        });
        settings.bind('confirm-clear', confirmRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(confirmRow);

        const stripRow = new Adw.SwitchRow({
            title: _('Strip text'),
            subtitle: _('Trim whitespace from copied text'),
        });
        settings.bind('strip-text', stripRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(stripRow);

        const moveRow = new Adw.SwitchRow({
            title: _('Move item first'),
            subtitle: _('Selected entries jump to the top of history'),
        });
        settings.bind('move-item-first', moveRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(moveRow);

        const cacheRow = new Adw.SwitchRow({
            title: _('Cache only favorites'),
            subtitle: _('Only pinned entries survive a restart'),
        });
        settings.bind('cache-only-favorites', cacheRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(cacheRow);

        const keysGroup = new Adw.PreferencesGroup({title: _('Keyboard shortcuts')});
        page.add(keysGroup);

        const makeShortcutRow = (key, title) => {
            const row = new Adw.EntryRow({
                title: `${title} (${_('empty disables')})`,
                show_apply_button: true,
                text: settings.get_strv(key)[0] ?? '',
            });
            row.connect('apply', () => {
                const accel = row.text.trim();
                if (accel && !Gtk.accelerator_parse(accel)[0]) {
                    row.add_css_class('error');
                    return;
                }
                row.remove_css_class('error');
                settings.set_strv(key, accel ? [accel] : []);
            });
            keysGroup.add(row);
        };

        makeShortcutRow('popup-shortcut', _('Popup at pointer'));
        makeShortcutRow('next-entry', _('Next entry (older)'));
        makeShortcutRow('prev-entry', _('Previous entry (newer)'));
        makeShortcutRow('toggle-private-mode', _('Toggle private mode'));
    }
}
